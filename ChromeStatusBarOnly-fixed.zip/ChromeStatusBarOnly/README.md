# Chrome StatusBar Only

A minimal LSPosed/Xposed module that does exactly one thing:

- Target: `com.android.chrome`
- Hide: Android STATUS BAR only
- Keep: navigation bar / gesture bar
- Keep: Chrome address bar and toolbar
- Does not change Vulkan, SystemUI, bottom bar, Edge-to-Edge flags, or other apps.

## Build

Open this folder in Android Studio and build:

`app > Tasks > build > assembleDebug`

APK output:

`app/build/outputs/apk/apk/debug/app-debug.apk`

## Install

1. Install the APK.
2. Enable it in LSPosed.
3. Scope it ONLY to Google Chrome (`com.android.chrome`).
4. Force-stop Chrome and reopen it.

## Notes

The module uses Android `WindowInsetsController.hide(WindowInsets.Type.statusBars())`.
It deliberately does NOT request `navigationBars()`, so the bottom navigation/gesture area is untouched.

If Chrome or the ROM re-applies its system-bar state, the module retries the status-bar hide shortly after Activity resume.
