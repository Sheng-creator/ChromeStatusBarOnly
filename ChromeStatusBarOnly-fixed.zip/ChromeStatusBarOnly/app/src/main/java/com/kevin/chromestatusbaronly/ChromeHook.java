package com.kevin.chromestatusbaronly;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Chrome StatusBar Only
 *
 * Only hides the Android STATUS BAR in com.android.chrome.
 * Navigation bar, gesture bar, Chrome toolbar, Vulkan, and other UI are untouched.
 */
public class ChromeHook implements IXposedHookLoadPackage {

    private static final String CHROME_PACKAGE = "com.android.chrome";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!CHROME_PACKAGE.equals(lpparam.packageName)) {
            return;
        }

        try {
            // Register lifecycle callbacks from Chrome's Application object.
            XposedHelpers.findAndHookMethod(
                    Application.class,
                    "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Application app = (Application) param.thisObject;

                            app.registerActivityLifecycleCallbacks(
                                    new Application.ActivityLifecycleCallbacks() {
                                        @Override
                                        public void onActivityResumed(final Activity activity) {
                                            hideStatusBar(activity);

                                            // Chrome may re-apply its system-bar state after resume.
                                            // Retry a few times, but ONLY for the status bar.
                                            View decor = activity.getWindow().getDecorView();
                                            decor.postDelayed(() -> hideStatusBar(activity), 150);
                                            decor.postDelayed(() -> hideStatusBar(activity), 500);
                                            decor.postDelayed(() -> hideStatusBar(activity), 1200);
                                        }

                                        @Override
                                        public void onActivityCreated(Activity a, Bundle b) {}
                                        @Override
                                        public void onActivityStarted(Activity a) {}
                                        @Override
                                        public void onActivityPaused(Activity a) {}
                                        @Override
                                        public void onActivityStopped(Activity a) {}
                                        @Override
                                        public void onActivitySaveInstanceState(Activity a, Bundle b) {}
                                        @Override
                                        public void onActivityDestroyed(Activity a) {}
                                    }
                            );
                        }
                    }
            );

        } catch (Throwable t) {
            XposedBridge.log("ChromeStatusBarOnly: " + t);
        }
    }

    private static void hideStatusBar(Activity activity) {
        try {
            Window window = activity.getWindow();
            WindowInsetsController controller = window.getInsetsController();

            if (controller != null) {
                // IMPORTANT: statusBars() ONLY.
                // Navigation bar is deliberately NOT included.
                controller.hide(WindowInsets.Type.statusBars());

                // Allow the status bar to appear temporarily from a system-edge gesture.
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } catch (Throwable t) {
            XposedBridge.log("ChromeStatusBarOnly hideStatusBar: " + t);
        }
    }
}
