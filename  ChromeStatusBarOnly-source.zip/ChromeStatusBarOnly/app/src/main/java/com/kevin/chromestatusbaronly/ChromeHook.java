package com.kevin.chromestatusbaronly;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Chrome StatusBar Only v1.1
 *
 * Targets Chrome Stable and Chrome Beta.
 * Hides ONLY Android's top status bar. It deliberately does not hide the
 * navigation/gesture bar or change Chrome's own toolbar/UI.
 */
public class ChromeHook implements IXposedHookLoadPackage {

    private static final String CHROME_STABLE = "com.android.chrome";
    private static final String CHROME_BETA = "com.chrome.beta";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        final String pkg = lpparam.packageName;
        if (!CHROME_STABLE.equals(pkg) && !CHROME_BETA.equals(pkg)) {
            return;
        }

        XposedBridge.log("ChromeStatusBarOnly: loaded for " + pkg);

        try {
            XposedHelpers.findAndHookMethod(
                    Application.class,
                    "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            final Application app = (Application) param.thisObject;
                            app.registerActivityLifecycleCallbacks(
                                    new Application.ActivityLifecycleCallbacks() {
                                        @Override
                                        public void onActivityCreated(Activity activity, Bundle state) {
                                            scheduleHide(activity);
                                        }

                                        @Override
                                        public void onActivityStarted(Activity activity) {
                                            scheduleHide(activity);
                                        }

                                        @Override
                                        public void onActivityResumed(Activity activity) {
                                            scheduleHide(activity);
                                        }

                                        @Override
                                        public void onActivityPaused(Activity activity) {}

                                        @Override
                                        public void onActivityStopped(Activity activity) {}

                                        @Override
                                        public void onActivitySaveInstanceState(Activity activity, Bundle state) {}

                                        @Override
                                        public void onActivityDestroyed(Activity activity) {}
                                    }
                            );
                            XposedBridge.log("ChromeStatusBarOnly: lifecycle registered for " + pkg);
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("ChromeStatusBarOnly: hook failed for " + pkg + ": " + t);
        }
    }

    private static void scheduleHide(final Activity activity) {
        try {
            final View decor = activity.getWindow().getDecorView();
            hideStatusBar(activity);

            // Chrome can update its window insets shortly after lifecycle events.
            // Retry only the STATUS BAR; navigation/gesture bars are untouched.
            decor.postDelayed(() -> hideStatusBar(activity), 100);
            decor.postDelayed(() -> hideStatusBar(activity), 300);
            decor.postDelayed(() -> hideStatusBar(activity), 700);
            decor.postDelayed(() -> hideStatusBar(activity), 1200);
        } catch (Throwable t) {
            XposedBridge.log("ChromeStatusBarOnly: schedule failed: " + t);
        }
    }

    private static void hideStatusBar(Activity activity) {
        try {
            Window window = activity.getWindow();
            WindowInsetsController controller = window.getInsetsController();
            if (controller == null) {
                return;
            }

            // IMPORTANT: statusBars() ONLY. Never navigationBars().
            controller.hide(WindowInsets.Type.statusBars());
            controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            );
        } catch (Throwable t) {
            XposedBridge.log("ChromeStatusBarOnly: hide failed: " + t);
        }
    }
}
