# Chrome StatusBar Only v1.1

LSPosed/Xposed module for Android.

## Targets
- Chrome Stable: `com.android.chrome`
- Chrome Beta: `com.chrome.beta`

Chrome Beta's current Android package ID is `com.chrome.beta`.

## Behavior
- Hides only Android's top status bar.
- Does NOT hide the navigation/gesture bar.
- Does NOT modify Chrome's toolbar or other UI.
- Does not touch Vulkan, HyperCeiler, or other system settings.

## Install
1. Install the APK.
2. Enable the module in LSPosed.
3. Add the Chrome Beta scope (`com.chrome.beta`) and/or Chrome Stable scope (`com.android.chrome`).
4. Force-stop the browser and reopen it; reboot if LSPosed asks for it.
